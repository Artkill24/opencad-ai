from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import os
from llm_pipeline import generate_cad_code_with_repair
from cad_engine import execute_and_export
from geometry_checks import detect_static_warnings
from dfm_checks import analyze_manufacturability, MATERIALS

app = FastAPI(title="OpenCAD-AI Core Backend", version="0.1.0")

os.makedirs("outputs", exist_ok=True)
app.mount("/outputs", StaticFiles(directory="outputs"), name="outputs")
app.mount("/static", StaticFiles(directory="static"), name="static")


class CADRequest(BaseModel):
    prompt: str
    output_name: str = "generated_model"
    timeout: int = 15
    max_attempts: int = 3
    material: str = "PLA"
    overhang_threshold_deg: float = 45.0
    min_wall_warn_mm: float = 1.0


@app.get("/")
async def serve_frontend():
    return FileResponse("static/index.html")


@app.get("/api/v1/materials")
async def list_materials():
    return {"materials": list(MATERIALS.keys())}


@app.post("/api/v1/generate")
async def generate_cad(request: CADRequest):
    output_dir = "outputs"
    os.makedirs(output_dir, exist_ok=True)
    file_prefix = os.path.join(output_dir, request.output_name)

    def execute_fn(code: str) -> dict:
        return execute_and_export(code, base_filename=file_prefix, timeout=request.timeout)

    repair_result = generate_cad_code_with_repair(
        request.prompt, execute_fn, max_attempts=request.max_attempts
    )

    python_code = repair_result["code"]
    exec_result = repair_result["exec_result"]

    if not exec_result["success"]:
        raise HTTPException(
            status_code=422,
            detail={
                "status": "compilation_error",
                "message": exec_result["error"],
                "generated_code": python_code,
                "attempts": repair_result["attempts"],
            }
        )

    warnings = detect_static_warnings(python_code)

    # L'analisi DFM gira solo su un export riuscito, e non deve mai far
    # fallire la richiesta: un problema qui è un'informazione in meno,
    # non un motivo per buttare via un pezzo generato correttamente.
    dfm = analyze_manufacturability(
        stl_path=exec_result["files"]["stl_path"],
        volume_mm3=exec_result.get("volume_mm3") or 0.0,
        material=request.material,
        overhang_threshold_deg=request.overhang_threshold_deg,
        min_wall_warn_mm=request.min_wall_warn_mm,
    )
    warnings = warnings + dfm.get("warnings", [])

    status = "geometria_sospetta" if warnings else "success"

    return {
        "status": status,
        "warnings": warnings,
        "generated_code": python_code,
        "volume_mm3": exec_result.get("volume_mm3"),
        "bbox_mm": exec_result.get("bbox_mm"),
        "files": exec_result["files"],
        "attempts": repair_result["attempts"],
        "repaired": repair_result["repaired"],
        "dfm": {
            "weight_cost": dfm.get("weight_cost"),
            "overhangs": dfm.get("overhangs"),
            "wall_thickness": dfm.get("wall_thickness"),
        },
    }


@app.get("/health")
def health_check():
    return {"status": "ok"}
