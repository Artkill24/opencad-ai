"""
Analisi DFM (Design for Manufacturing) sul file STL già esportato.

Tre controlli, con onestà esplicita sui limiti di ciascuno:

1. Peso e costo materiale -- calcolo diretto da volume x densità, affidabile
   quanto lo è il volume stesso (già verificato altrove nella pipeline).
   I prezzi/kg sono INDICATIVI (variano per fornitore, quantità, mercato) --
   vanno trattati come riferimento, non come preventivo.

2. Overhang (sbalzi senza supporto, rilevante per stampa 3D FDM) -- calcolo
   geometrico esatto sulla mesh: per ogni triangolo, l'angolo tra la sua
   normale e la verticale verso il basso. Affidabile quanto la mesh STL
   esportata (tolleranza 0.01mm, dovrebbe essere adeguata).

3. Spessore minimo pareti -- STIMA CAMPIONATA via ray casting da un
   sottoinsieme di facce, non un'analisi esaustiva. Può non individuare
   punti sottili isolati che non sono allineati con nessuna faccia
   campionata. Utile come segnale d'allarme, non come sostituto di un
   controllo DFM professionale.
"""

import numpy as np
import trimesh

# Densità (g/cm^3) e prezzo indicativo (EUR/kg, solo materiale grezzo,
# NESSUNA lavorazione/stampa/finitura inclusa) -- valori di riferimento
# ampiamente citati in letteratura tecnica, da verificare sempre col
# fornitore reale prima di usarli per un preventivo.
MATERIALS = {
    "PLA":      {"density_g_cm3": 1.24, "price_eur_kg": 20.0},
    "ABS":      {"density_g_cm3": 1.04, "price_eur_kg": 22.0},
    "PETG":     {"density_g_cm3": 1.27, "price_eur_kg": 25.0},
    "NYLON_PA12": {"density_g_cm3": 1.01, "price_eur_kg": 30.0},
    "ALLUMINIO_6061": {"density_g_cm3": 2.70, "price_eur_kg": 6.0},
    "ACCIAIO":  {"density_g_cm3": 7.85, "price_eur_kg": 2.0},
}

DEFAULT_OVERHANG_THRESHOLD_DEG = 45.0
DEFAULT_MIN_WALL_WARN_MM = 1.0
DEFAULT_THICKNESS_SAMPLE_COUNT = 250


def _compute_weight_and_cost(volume_mm3: float, material: str) -> dict:
    material_key = material.upper()
    if material_key not in MATERIALS:
        return {
            "material": material,
            "error": f"Materiale '{material}' non in elenco. Disponibili: {', '.join(MATERIALS.keys())}",
        }

    props = MATERIALS[material_key]
    volume_cm3 = volume_mm3 / 1000.0
    weight_g = volume_cm3 * props["density_g_cm3"]
    cost_eur = (weight_g / 1000.0) * props["price_eur_kg"]

    return {
        "material": material_key,
        "weight_g": round(weight_g, 2),
        "estimated_cost_eur": round(cost_eur, 2),
        "cost_disclaimer": "Prezzo indicativo del solo materiale grezzo -- verifica sempre col fornitore.",
    }


def _compute_overhangs(mesh: trimesh.Trimesh, threshold_deg: float) -> dict:
    normals = mesh.face_normals
    areas = mesh.area_faces
    total_area = areas.sum()

    if total_area <= 0:
        return {"overhang_area_pct": None, "note": "Area totale della mesh nulla, impossibile analizzare."}

    normal_z = normals[:, 2]
    downward_mask = normal_z < 0

    # Angolo tra la normale e la verticale verso il basso (0,0,-1):
    # 0 gradi = faccia orizzontale rivolta in basso (sbalzo peggiore possibile),
    # 90 gradi = faccia verticale (mai a rischio, indipendentemente dalla soglia).
    alpha_deg = np.degrees(np.arccos(np.clip(-normal_z, -1.0, 1.0)))

    # La faccia alla base del pezzo (appoggiata sul piano di stampa) NON è
    # un overhang, anche se la sua normale punta verso il basso -- è
    # banalmente supportata dal piano stesso. Senza questa esclusione, un
    # semplice cubo pieno risulterebbe segnalato per la propria base
    # (verificato con un test su geometria nota: falso positivo confermato
    # prima di questa correzione).
    z_min = mesh.bounds[0][2]
    base_epsilon = max(mesh.scale * 1e-4, 1e-3)
    face_min_z = mesh.triangles[:, :, 2].min(axis=1)
    at_base_mask = face_min_z <= (z_min + base_epsilon)

    risky_mask = downward_mask & (alpha_deg < threshold_deg) & (~at_base_mask)
    risky_area = areas[risky_mask].sum()
    overhang_pct = 100.0 * risky_area / total_area

    return {
        "overhang_area_pct": round(overhang_pct, 2),
        "overhang_threshold_deg": threshold_deg,
        "note": (
            "Percentuale di superficie (esclusa la base d'appoggio) con normale rivolta "
            f"verso il basso a meno di {threshold_deg:.0f} gradi dalla verticale -- "
            "indicativo per stampa 3D FDM, potrebbe richiedere supporti."
        ),
    }


def _estimate_min_wall_thickness(mesh: trimesh.Trimesh, sample_count: int) -> dict:
    n_faces = len(mesh.faces)
    if n_faces == 0:
        return {"estimated_min_wall_mm": None, "note": "Mesh senza facce."}

    if n_faces > sample_count:
        idx = np.random.default_rng(42).choice(n_faces, sample_count, replace=False)
    else:
        idx = np.arange(n_faces)

    centers = mesh.triangles_center[idx]
    normals = mesh.face_normals[idx]

    # Scostamento verso l'interno per evitare che il raggio colpisca
    # immediatamente la propria faccia di partenza (auto-intersezione a
    # distanza ~0). Scala con la dimensione del pezzo, non un valore fisso.
    epsilon = max(mesh.scale * 1e-4, 1e-4)
    origins = centers - normals * epsilon
    directions = -normals

    try:
        locations, index_ray, _ = mesh.ray.intersects_location(origins, directions)
    except Exception as e:
        return {"estimated_min_wall_mm": None, "note": f"Ray casting non riuscito: {e}"}

    if len(locations) == 0:
        return {
            "estimated_min_wall_mm": None,
            "note": "Nessuna intersezione trovata nel campione -- mesh probabilmente troppo semplice/aperta per questa stima.",
        }

    distances = np.linalg.norm(locations - origins[index_ray], axis=1)

    # Un raggio può colpire più facce lungo il suo percorso (mesh non
    # perfettamente convesse): teniamo solo la distanza minima per ciascun
    # raggio, che rappresenta lo spessore locale nel punto campionato.
    min_per_ray = {}
    for dist, ray_idx in zip(distances, index_ray):
        if ray_idx not in min_per_ray or dist < min_per_ray[ray_idx]:
            min_per_ray[ray_idx] = dist

    if not min_per_ray:
        return {"estimated_min_wall_mm": None, "note": "Nessuna distanza valida calcolata."}

    all_thicknesses = list(min_per_ray.values())
    estimated_min = min(all_thicknesses)

    return {
        "estimated_min_wall_mm": round(float(estimated_min), 3),
        "sample_count": len(idx),
        "note": (
            "STIMA CAMPIONATA (ray casting da un sottoinsieme di facce), non un'analisi "
            "esaustiva -- può non rilevare punti sottili isolati non allineati col campione."
        ),
    }


def analyze_manufacturability(
    stl_path: str,
    volume_mm3: float,
    material: str = "PLA",
    overhang_threshold_deg: float = DEFAULT_OVERHANG_THRESHOLD_DEG,
    min_wall_warn_mm: float = DEFAULT_MIN_WALL_WARN_MM,
    thickness_sample_count: int = DEFAULT_THICKNESS_SAMPLE_COUNT,
) -> dict:
    """
    Analisi DFM completa su un file STL esportato. Ritorna un dict con
    weight_cost, overhangs, wall_thickness, e una lista di warnings testuali
    se qualche soglia viene superata. Non solleva eccezioni verso il
    chiamante: eventuali errori vengono incorporati nel dict di risposta,
    perché un fallimento qui non deve mai far fallire l'intera richiesta
    di generazione (il pezzo è comunque stato generato con successo).
    """
    result = {
        "weight_cost": _compute_weight_and_cost(volume_mm3, material),
        "overhangs": None,
        "wall_thickness": None,
        "warnings": [],
    }

    try:
        mesh = trimesh.load_mesh(stl_path)
    except Exception as e:
        result["warnings"].append(f"Impossibile caricare la mesh per l'analisi DFM: {e}")
        return result

    overhangs = _compute_overhangs(mesh, overhang_threshold_deg)
    result["overhangs"] = overhangs
    if overhangs.get("overhang_area_pct") is not None and overhangs["overhang_area_pct"] > 5.0:
        result["warnings"].append(
            f"{overhangs['overhang_area_pct']:.1f}% della superficie ha sbalzi a rischio "
            f"(sotto {overhang_threshold_deg:.0f} gradi dalla verticale) -- valuta supporti "
            "in stampa o un riorientamento del pezzo."
        )

    thickness = _estimate_min_wall_thickness(mesh, thickness_sample_count)
    result["wall_thickness"] = thickness
    est = thickness.get("estimated_min_wall_mm")
    if est is not None and est < min_wall_warn_mm:
        result["warnings"].append(
            f"Spessore minimo stimato {est}mm, sotto la soglia di {min_wall_warn_mm}mm -- "
            "rischio di rottura in produzione (stima campionata, verifica visivamente)."
        )

    return result
