import sys
import io
import math
import traceback
import multiprocessing
import cadquery as cq
import trimesh

from polyhedra import build_platonic_solid


def _run_in_subprocess(code_str: str, step_path: str, stl_path: str, queue: multiprocessing.Queue):
    """
    Gira in un processo separato: exec dello script, validazione result,
    export STEP/STL, calcolo volume/bounding box per verifica geometrica.
    Comunica solo dati picklabili (dict) al processo padre.
    """
    local_scope = {}
    # 'math' è sempre disponibile nell'ambiente di esecuzione, anche se il
    # codice generato non scrive esplicitamente "import math" -- capita
    # spesso su geometrie che richiedono trigonometria (poliedri, eliche)
    # dove il modello usa math.cos/math.sin ma dimentica l'import. Evita
    # un'intera classe di NameError altrimenti ricorrente in quei casi.
    #
    # 'build_platonic_solid' è disponibile per lo stesso motivo, ma per un
    # problema più profondo: il modello falliva ripetutamente (3-4 tentativi,
    # errori diversi ogni volta) provando a calcolare da solo i vertici di
    # un icosaedro con trigonometria a mano. Dargli una funzione già pronta
    # e verificata (vedi polyhedra.py) sposta il compito da "inventa la
    # geometria" a "scegli quale solido e quale dimensione".
    global_scope = {"cq": cq, "math": math, "build_platonic_solid": build_platonic_solid}

    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    try:
        exec(code_str, global_scope, local_scope)
        result = local_scope.get("result")

        if result is None:
            queue.put({"success": False, "error": "Lo script non ha definito la variabile 'result'."})
            return

        # Due percorsi possibili per 'result': un solido CadQuery normale
        # (Workplane/Assembly, la stragrande maggioranza dei casi -- export
        # STEP+STL via OCCT), oppure una mesh trimesh prodotta da
        # build_platonic_solid() -- export SOLO STL, perché una mesh
        # triangolare non è un solido BREP e non può produrre uno STEP
        # valido (vedi nota in polyhedra.py sul perché di questa scelta).
        if isinstance(result, trimesh.Trimesh):
            result.export(stl_path)

            queue.put({
                "success": True,
                "error": None,
                "volume_mm3": round(float(result.volume), 1),
                "bbox_mm": {
                    "x": round(float(result.extents[0]), 2),
                    "y": round(float(result.extents[1]), 2),
                    "z": round(float(result.extents[2]), 2),
                },
                "mesh_only": True,  # cad_engine comunica al chiamante che non c'è uno STEP
            })
            return

        if not isinstance(result, (cq.Workplane, cq.Assembly)):
            queue.put({
                "success": False,
                "error": (
                    f"'result' deve essere cq.Workplane, cq.Assembly, o il risultato di "
                    f"build_platonic_solid(), ottenuto {type(result)}."
                )
            })
            return

        cq.exporters.export(result, step_path, exportType=cq.exporters.ExportTypes.STEP)
        cq.exporters.export(
            result, stl_path,
            exportType=cq.exporters.ExportTypes.STL,
            tolerance=0.01, angularTolerance=0.1
        )

        # Metriche geometriche per verifica post-hoc (solo per Workplane con un solido;
        # per geometrie composite/Assembly il calcolo è meno affidabile, lo saltiamo).
        volume_mm3 = None
        bbox_mm = None
        try:
            solid = result.val()
            if hasattr(solid, "Volume") and hasattr(solid, "BoundingBox"):
                volume_mm3 = round(solid.Volume(), 1)
                bbox = solid.BoundingBox()
                bbox_mm = {
                    "x": round(bbox.xlen, 2),
                    "y": round(bbox.ylen, 2),
                    "z": round(bbox.zlen, 2),
                }
        except Exception:
            pass  # metriche opzionali: se falliscono non blocchiamo l'export già riuscito

        queue.put({
            "success": True,
            "error": None,
            "volume_mm3": volume_mm3,
            "bbox_mm": bbox_mm,
            "mesh_only": False,
        })

    except Exception as e:
        queue.put({"success": False, "error": f"{str(e)}\n{traceback.format_exc()}"})
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr


def execute_and_export(code_str: str, base_filename: str = "output", timeout: int = 15) -> dict:
    """
    Esegue lo script CadQuery in un processo isolato con timeout hard.
    Ritorna dict con success, error, volume/bbox (se disponibili), e (se ok) files.
    files["step_path"] è None per i risultati mesh-only (solidi platonici via
    trimesh) -- non esiste alcuno STEP per quei casi, vedi mesh_only in result.
    """
    step_path = f"{base_filename}.step"
    stl_path = f"{base_filename}.stl"

    queue = multiprocessing.Queue()
    proc = multiprocessing.Process(
        target=_run_in_subprocess,
        args=(code_str, step_path, stl_path, queue)
    )
    proc.start()
    proc.join(timeout)

    if proc.is_alive():
        proc.terminate()
        proc.join()
        return {
            "success": False,
            "error": f"Timeout: esecuzione oltre {timeout}s (probabile loop infinito o geometria troppo complessa)."
        }

    if queue.empty():
        return {
            "success": False,
            "error": f"Processo terminato senza risultato (crash, exit code {proc.exitcode})."
        }

    result = queue.get()
    if result["success"]:
        result["files"] = {
            "step_path": None if result.get("mesh_only") else step_path,
            "stl_path": stl_path,
        }
    return result
