"""
Solidi platonici pronti all'uso, per evitare che il modello LLM debba
inventare la matematica dei vertici/facce ogni volta (dove ha fallito
ripetutamente su un icosaedro: NameError diversi a ogni tentativo di
repair, perché il problema non era un dettaglio sintattico ma l'approccio
stesso -- calcolare trigonometria a mano è fragile).

Approccio: qui generiamo solo le COORDINATE dei vertici (formule
matematiche standard, verificate contro le formule di volume note --
vedi test in fondo al modulo) e lasciamo che un algoritmo di convex hull
(scipy) calcoli automaticamente la triangolazione delle facce. Questo
elimina la classe di errore "ho sbagliato a scrivere a mano gli indici
delle facce" -- il rischio più alto in questo tipo di implementazione.

L'orientazione delle normali (che il convex hull NON garantisce coerente)
viene corretta esplicitamente: ogni triangolo viene riordinato in modo che
la sua normale punti sempre verso l'esterno rispetto al centro del solido.
Senza questa correzione, alcuni triangoli avrebbero normale invertita e la
shell risultante non sarebbe un solido valido per CadQuery/OCCT.
"""

import math

import numpy as np
from scipy.spatial import ConvexHull

import cadquery as cq

PHI = (1 + math.sqrt(5)) / 2  # rapporto aureo, usato da icosaedro e dodecaedro


def _tetrahedron_vertices():
    return [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]


def _cube_vertices():
    return [(x, y, z) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]


def _octahedron_vertices():
    return [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]


def _icosahedron_vertices():
    verts = []
    for s1 in (-1, 1):
        for s2 in (-1, 1):
            verts.append((0, s1 * 1, s2 * PHI))
            verts.append((s1 * 1, s2 * PHI, 0))
            verts.append((s2 * PHI, 0, s1 * 1))
    return verts


def _dodecahedron_vertices():
    verts = [(x, y, z) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1)]
    inv_phi = 1 / PHI
    for s1 in (-1, 1):
        for s2 in (-1, 1):
            verts.append((0, s1 * inv_phi, s2 * PHI))
            verts.append((s1 * inv_phi, s2 * PHI, 0))
            verts.append((s2 * PHI, 0, s1 * inv_phi))
    return verts


# Nomi in italiano (quello che userà il system prompt / l'utente) mappati
# ai generatori di vertici. Tutti i solidi qui sono centrati nell'origine
# e hanno tutti i vertici equidistanti da essa (proprietà dei solidi
# platonici regolari) -- questo rende valida la normalizzazione per
# diametro circoscritto usata in build_platonic_solid().
PLATONIC_SOLIDS = {
    "tetraedro": _tetrahedron_vertices,
    "cubo": _cube_vertices,
    "ottaedro": _octahedron_vertices,
    "icosaedro": _icosahedron_vertices,
    "dodecaedro": _dodecahedron_vertices,
}


def _normalize_to_diameter(vertices, target_diameter):
    """
    Riscala i vertici in modo che il diametro circoscritto (distanza tra i
    due vertici più lontani, che per questi solidi centralmente simmetrici
    equivale a 2x la distanza di un vertice qualsiasi dall'origine) sia
    esattamente target_diameter. Corrisponde a "misura la dimensione più
    larga del pezzo con un calibro", il modo più naturale di prendere una
    misura reale su un oggetto fisico.
    """
    pts = np.array(vertices, dtype=float)
    current_diameter = 2 * np.linalg.norm(pts[0])
    factor = target_diameter / current_diameter
    return (pts * factor).tolist()


def _oriented_triangle(pts, tri):
    """
    Riordina i tre vertici del triangolo così che la normale punti sempre
    verso l'esterno del solido (lontano dal centro). ConvexHull non
    garantisce questa coerenza -- verificato empiricamente: senza questa
    correzione i contributi di volume si cancellano a vicenda invece di
    sommarsi (vedi commento in testa al modulo).
    """
    p0, p1, p2 = pts[tri[0]], pts[tri[1]], pts[tri[2]]
    normal = np.cross(p1 - p0, p2 - p0)
    centroid = (p0 + p1 + p2) / 3.0
    if np.dot(normal, centroid) < 0:
        p1, p2 = p2, p1
    return p0, p1, p2


def build_platonic_solid(name: str, diameter_mm: float) -> cq.Workplane:
    """
    Costruisce un solido platonico come cq.Workplane pronto per essere
    assegnato a 'result', con diametro circoscritto pari a diameter_mm.

    name: uno tra "tetraedro", "cubo", "ottaedro", "icosaedro", "dodecaedro".
    diameter_mm: distanza tra i due punti più lontani del solido (il tipo
    di misura che si prende naturalmente con un calibro sull'oggetto reale).
    """
    key = name.strip().lower()
    if key not in PLATONIC_SOLIDS:
        raise ValueError(
            f"Solido platonico non supportato: '{name}'. "
            f"Disponibili: {', '.join(PLATONIC_SOLIDS.keys())}"
        )

    raw_vertices = PLATONIC_SOLIDS[key]()
    vertices = _normalize_to_diameter(raw_vertices, diameter_mm)

    pts = np.array(vertices, dtype=float)
    hull = ConvexHull(pts)

    faces = []
    for tri in hull.simplices:
        p0, p1, p2 = _oriented_triangle(pts, tri)
        wire = cq.Wire.makePolygon([cq.Vector(*p0), cq.Vector(*p1), cq.Vector(*p2)])
        faces.append(cq.Face.makeFromWires(wire))

    shell = cq.Shell.makeShell(faces)
    solid = cq.Solid.makeSolid(shell)
    return cq.Workplane(obj=solid)
