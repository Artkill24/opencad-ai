import os
import re
import httpx

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
# Configurabile via env: usa l'identificatore esatto del modello dalla
# pagina "Chiavi API" / documentazione se vuoi un modello diverso da questo default.
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash-lite")
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)

SYSTEM_PROMPT = """
Sei un ingegnere meccanico ed esperto dello script CadQuery in Python.
Il tuo compito è generare UNICAMENTE codice Python valido per CadQuery basato sulla richiesta dell'utente.

REGOLE RIGIDE:
1. Rispondi ESCLUSIVAMENTE con il blocco di codice Python all'interno di ```python ... ```. Nessun testo prima o dopo.
2. Il codice DEVE importare cadquery: `import cadquery as cq`.
3. Il solido finale DEVE essere assegnato alla variabile `result`.
4. Usa solo operazioni geometriche stabili e valide in CadQuery 2.4:
   `.box()`, `.cylinder()`, `.faces()`, `.workplane()`, `.hole()`, `.cut()`, `.fillet()`,
   `.chamfer()`, `.extrude()`, `.polarArray()`, `.rarray()`, `.union()`, `.cboreHole()`.
5. Per disporre feature (fori, bulloni) lungo una circonferenza usa `.polarArray(radius, startAngle, angle, count)`,
   NON esiste `.patternCircular()`.
6. Assegna tolleranze e quote realistiche in millimetri.
7. Per parti con PIÙ di una piastra/lamina unite (staffe a L, a T, a U, bracket multi-parte):
   È VIETATO chiamare `.union()` e poi `.hole()`/`.cut()` sul risultato per forare le piastre.
   Dopo `.union()`, le facce selezionabili con `.faces()` possono essere strette o non allineate
   col centro atteso, e `.center(x, y)` è relativo al centro del BOUNDING BOX della faccia
   selezionata (non al centro del materiale) — il foro finisce spesso fuori dal solido SENZA
   generare alcun errore (fallimento silenzioso, non rilevabile da compilazione o traceback).
   ORDINE OBBLIGATORIO: 1) crea ogni piastra come solido rettangolare indipendente,
   2) fora OGNI piastra separatamente mentre è ancora un box isolato (qui `.center()` è
   affidabile perché la faccia è un rettangolo pieno e il suo bounding box coincide col
   materiale), 3) SOLO ALLA FINE unisci i solidi già forati con `.union()`.
8. Per SOLIDI PLATONICI REGOLARI (tetraedro, cubo, ottaedro, icosaedro, dodecaedro) è
   disponibile la funzione `build_platonic_solid(nome, diameter_mm)`, GIÀ IMPORTATA e pronta
   all'uso — NON provare a calcolare vertici/facce a mano con trigonometria, è un approccio
   fragile che fallisce quasi sempre (verificato ripetutamente). `nome` è una stringa tra
   "tetraedro", "cubo", "ottaedro", "icosaedro", "dodecaedro"; `diameter_mm` è il diametro
   circoscritto (distanza tra i due punti più lontani del solido, quello che si misura con un
   calibro sull'oggetto reale). La funzione ritorna direttamente un cq.Workplane pronto per
   essere assegnato a `result` (o ulteriormente lavorato con `.cut()`, `.union()`, ecc. se serve
   aggiungere fori o altre feature).

ESEMPIO 1 (Flangia forata con 4 fori):
```python
import cadquery as cq

outer_diameter = 100.0
inner_diameter = 40.0
thickness = 10.0
bolt_circle_diameter = 75.0
bolt_hole_diameter = 8.5
num_holes = 4

result = (
    cq.Workplane("XY")
    .circle(outer_diameter / 2)
    .circle(inner_diameter / 2)
    .extrude(thickness)
    .faces(">Z")
    .workplane()
    .polarArray(bolt_circle_diameter / 2, 0, 360, num_holes)
    .hole(bolt_hole_diameter)
)
```

ESEMPIO 2 (Staffa a L con foro su ciascuna piastra — pattern corretto multi-solido):
```python
import cadquery as cq

plate_length = 60.0
plate_width = 30.0
thickness = 5.0
hole_diameter = 8.0

# Piastra orizzontale: rettangolo pieno, foro inciso col proprio centro locale
horizontal_plate = (
    cq.Workplane("XY")
    .box(plate_length, plate_width, thickness, centered=(False, False, False))
    .faces(">Z")
    .workplane()
    .center(plate_length / 2, plate_width / 2)
    .hole(hole_diameter)
)

# Piastra verticale: stesso principio, poi ruotata e traslata per unirsi a 90 gradi
vertical_plate = (
    cq.Workplane("XY")
    .box(plate_length, plate_width, thickness, centered=(False, False, False))
    .faces(">Z")
    .workplane()
    .center(plate_length / 2, plate_width / 2)
    .hole(hole_diameter)
    .rotate((0, 0, 0), (0, 1, 0), 90)
    .translate((0, 0, thickness))
)

result = horizontal_plate.union(vertical_plate)
```

ESEMPIO 3 (Icosaedro con diametro circoscritto 40mm — usa la funzione pronta, non trigonometria a mano):
```python
import cadquery as cq

result = build_platonic_solid("icosaedro", diameter_mm=40.0)
```
"""


def _call_gemini(contents: list, system_instruction: str = None) -> str:
    """
    Chiamata Gemini grezza: manda la history dei turni ('contents' nel formato
    dell'API), ritorna il testo della risposta. Non fa parsing del codice --
    quello resta responsabilità del chiamante, perché il chiamante sa se sta
    gestendo il primo turno o un turno di correzione.

    system_instruction: override opzionale del system prompt di default
    (SYSTEM_PROMPT, specializzato per generare CadQuery). Usato da
    vision_pipeline.py per lo step di visione, che ha un compito diverso
    (descrivere, non generare codice) e quindi un system prompt diverso --
    ma la meccanica della chiamata HTTP è identica, niente da duplicare.
    """
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY non impostata in .env")

    payload = {
        "system_instruction": {"parts": [{"text": system_instruction or SYSTEM_PROMPT}]},
        "contents": contents,
        "generationConfig": {"temperature": 0.1},
    }

    with httpx.Client(timeout=60.0) as http_client:
        resp = http_client.post(
            GEMINI_URL,
            params={"key": GEMINI_API_KEY},
            json=payload,
        )

    if resp.status_code != 200:
        raise RuntimeError(
            f"Errore API Gemini ({resp.status_code}): {resp.text}"
        )

    data = resp.json()
    try:
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError) as e:
        raise RuntimeError(f"Risposta Gemini in formato inatteso: {data}") from e


def _extract_code(response_text: str) -> str:
    """Estrae il blocco ```python ... ``` dalla risposta, con fallback se il formato non è rispettato."""
    match = re.search(r"```python\n(.*?)\n```", response_text, re.DOTALL)
    if match:
        return match.group(1).strip()

    code_lines = [line for line in response_text.split("\n") if not line.strip().startswith("```")]
    return "\n".join(code_lines).strip()


def _summarize_error(error_msg: str, max_chars: int = 600) -> str:
    """
    I traceback di CadQuery/OCCT sono spesso enormi e pieni di rumore interno
    (frame di libreria C++, path assoluti). Mandiamo al modello solo la parte
    utile: la prima riga (di solito 'TipoErrore: messaggio') più eventuali
    righe successive fino al limite di caratteri, non l'intero traceback.
    """
    lines = error_msg.strip().split("\n")
    summary = lines[0]
    for line in lines[1:]:
        if len(summary) + len(line) > max_chars:
            break
        summary += "\n" + line
    return summary


def generate_cad_code(prompt: str) -> str:
    """
    Genera codice CadQuery per un prompt, senza retry.
    Usata per compatibilità/test unitari puntuali. Il flusso con auto-repair
    è generate_cad_code_with_repair(), usata dall'endpoint.
    """
    contents = [{"role": "user", "parts": [{"text": f"Crea il modello CAD per: {prompt}"}]}]
    response_text = _call_gemini(contents)
    return _extract_code(response_text)


def generate_cad_code_with_repair(prompt: str, execute_fn, max_attempts: int = 3) -> dict:
    """
    Genera codice CadQuery con retry automatico sugli errori di COMPILAZIONE
    (non sui warning geometrici del rilevatore statico -- quelli sono euristiche,
    non certezze, e ritentarli alla cieca rischia di peggiorare casi corretti).

    execute_fn: callable che prende il codice generato e ritorna il dict di
    execute_and_export() (con "success"/"error"). Iniettato dal chiamante
    (main.py) invece di importato qui, per non creare una dipendenza
    circolare tra llm_pipeline e cad_engine e per restare testabile in isolamento.

    Ritorna un dict con: code, exec_result, attempts, repaired (bool).
    """
    contents = [{"role": "user", "parts": [{"text": f"Crea il modello CAD per: {prompt}"}]}]

    last_code = None
    last_exec_result = None

    for attempt in range(1, max_attempts + 1):
        response_text = _call_gemini(contents)
        code = _extract_code(response_text)
        exec_result = execute_fn(code)

        last_code = code
        last_exec_result = exec_result

        if exec_result["success"]:
            return {
                "code": code,
                "exec_result": exec_result,
                "attempts": attempt,
                "repaired": attempt > 1,
            }

        if attempt == max_attempts:
            break  # esaurito il budget di tentativi, usciamo col fallimento

        # Prepara il prossimo turno: il modello vede il proprio codice fallito
        # e l'errore esatto, come farebbe un collega che gli segnala un bug.
        error_summary = _summarize_error(exec_result["error"])
        contents.append({"role": "model", "parts": [{"text": response_text}]})
        contents.append({
            "role": "user",
            "parts": [{
                "text": (
                    f"Il codice ha generato questo errore durante l'esecuzione:\n\n"
                    f"{error_summary}\n\n"
                    "Correggi SOLO il problema che ha causato questo errore specifico. "
                    "Mantieni invariato il resto della logica. Rispondi di nuovo con "
                    "l'intero script corretto nello stesso formato ```python ... ```."
                )
            }]
        })

    return {
        "code": last_code,
        "exec_result": last_exec_result,
        "attempts": max_attempts,
        "repaired": False,
    }
