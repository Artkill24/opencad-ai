"""
Parti standard ISO/DIN reali (dadi esagonali, viti a testa esagonale) via
cq_warehouse (https://github.com/gumyr/cq_warehouse) -- dimensioni prese
da tabelle standard ufficiali incluse nel pacchetto, non stimate dal
modello.

AVVISO SUL RISCHIO (onestà, non solo formalità): l'ultimo commit del
progetto risale a settembre 2023, circa 4 mesi prima dell'uscita della
versione di CadQuery che usiamo qui (2.4.0). Nessuna garanzia formale di
compatibilità. VERIFICATO empiricamente prima di scrivere questo modulo,
non solo "sembra funzionare":
- HexNut M6-1 (iso4032): volume e bounding box confrontati con la
  geometria esagonale calcolata a mano (formula esatta larghezza tra i
  piatti <-> tra i vertici, volume prisma meno foro) -- scarto 0.33%.
- HexHeadScrew M6-1x25mm (iso4017): stessa verifica, scarto 0.05% una
  volta capito che 'simple=True' approssima il filetto con un cilindro
  al DIAMETRO MINORE (tecnica standard), non al diametro nominale.

Entrambe le classi (Nut, Screw) ereditano direttamente da cq.Solid
(non da Workplane) -- qui le incapsuliamo in un cq.Workplane per
uniformità con il resto della pipeline, stesso pattern di polyhedra.py.
"""

import cadquery as cq
from cq_warehouse.fastener import HexNut, HexHeadScrew

SUPPORTED_NUT_TYPES = ["iso4032", "iso4033", "iso4035"]
SUPPORTED_SCREW_TYPES = ["iso4014", "iso4017"]


def build_hex_nut(size: str, fastener_type: str = "iso4032") -> cq.Workplane:
    """
    Costruisce un dado esagonale standard ISO, pronto per essere assegnato
    a 'result'.

    size: designazione ISO del filetto, es. "M6-1" (M6, passo 1.0mm),
        "M8-1.25", "M10-1.5" -- il formato è "M<diametro>-<passo>".
    fastener_type: uno tra "iso4032" (dado esagonale standard),
        "iso4033" (dado esagonale stile 2, più alto), "iso4035"
        (dado esagonale ribassato, smussato).
    """
    if fastener_type not in SUPPORTED_NUT_TYPES:
        raise ValueError(
            f"Tipo di dado non supportato: '{fastener_type}'. "
            f"Disponibili: {', '.join(SUPPORTED_NUT_TYPES)}"
        )
    nut = HexNut(size=size, fastener_type=fastener_type, simple=True)
    return cq.Workplane(obj=nut)


def build_hex_head_screw(size: str, length_mm: float, fastener_type: str = "iso4017") -> cq.Workplane:
    """
    Costruisce una vite a testa esagonale standard ISO, pronta per essere
    assegnata a 'result'.

    size: designazione ISO del filetto, es. "M6-1" (M6, passo 1.0mm).
    length_mm: lunghezza del gambo filettato in mm (sotto la testa).
    fastener_type: "iso4014" (vite a testa esagonale, gambo parzialmente
        filettato) o "iso4017" (vite a testa esagonale, gambo completamente
        filettato).

    Nota: il filetto è approssimato con un cilindro liscio al diametro
    minore (tecnica standard per fasteners semplificati) -- non è una
    spirale filettata reale modellata geometricamente.
    """
    if fastener_type not in SUPPORTED_SCREW_TYPES:
        raise ValueError(
            f"Tipo di vite non supportato: '{fastener_type}'. "
            f"Disponibili: {', '.join(SUPPORTED_SCREW_TYPES)}"
        )
    screw = HexHeadScrew(size=size, length=length_mm, fastener_type=fastener_type, simple=True)
    return cq.Workplane(obj=screw)
