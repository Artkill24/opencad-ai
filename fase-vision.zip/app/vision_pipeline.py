"""
Foto -> descrizione geometrica testuale (NON foto -> CAD diretto).

Perché questa architettura e non "genera subito il modello dalla foto":
una singola fotografia non contiene l'informazione di scala necessaria per
misure affidabili -- senza un riferimento di dimensione nota nell'inquadratura
(una moneta, un righello, una misura data dall'utente), qualunque "misura"
estratta da un modello vision è una stima di proporzioni relative, non una
quota reale. Anche un ingegnere umano non potrebbe fare altrimenti guardando
la stessa foto.

Per questo il risultato di questo modulo è testo, non codice: la descrizione
finisce nella stessa textarea "Richiesta" che l'utente userebbe normalmente,
così la rivede e la corregge (in particolare le dimensioni, se non c'era un
riferimento di scala) PRIMA che venga generato qualunque solido. Da lì in poi
riusa tutta la pipeline esistente (repair loop, rilevatore geometrico, DFM)
senza bisogno di duplicare nulla.
"""

import base64

from llm_pipeline import _call_gemini

VISION_SYSTEM_PROMPT = """
Sei un ingegnere meccanico che osserva la fotografia di un oggetto fisico e
ne stima la geometria per poterlo ricreare come solido CAD parametrico.

Il tuo compito NON è generare codice: devi produrre una DESCRIZIONE TESTUALE
in italiano, nello stesso stile di una richiesta che un utente scriverebbe
per generare il pezzo (es. "Un cilindro forato di diametro 40mm e altezza
60mm, con un foro passante centrale da 10mm.").

REGOLE RIGIDE:
1. Descrivi l'oggetto come combinazione di forme geometriche semplici
   (cilindri, blocchi, coni, fori, smussi, pattern circolari) -- evita forme
   organiche, curve libere o dettagli che non si possono rappresentare con
   queste primitive. Se l'oggetto ha parti troppo complesse da ridurre a
   primitive semplici, semplifica e dillo esplicitamente.
2. Stima le dimensioni in millimetri. Se ti viene indicato un riferimento di
   scala presente nella foto (un oggetto di dimensione nota), USALO per
   calibrare per proporzione tutte le altre misure -- confronta le dimensioni
   in pixel nell'immagine tra l'oggetto target e il riferimento.
3. Se NON ti viene fornito alcun riferimento di scala, stima comunque le
   proporzioni relative nel modo più ragionevole possibile, ma apri la tua
   risposta con questa riga esatta, che il sistema userà per avvisare
   l'utente:
   [STIMA SENZA RIFERIMENTO DI SCALA -- dimensioni assolute incerte, verifica prima di generare]
4. Non descrivere colori, materiali, texture, riflessi o dettagli estetici --
   SOLO geometria: forma, dimensioni, fori, simmetrie, spessori.
5. Rispondi ESCLUSIVAMENTE con la descrizione testuale finale, pronta per
   essere usata come richiesta di generazione. Nessuna premessa, nessuna
   spiegazione del tuo ragionamento, nessun markdown.
"""


def describe_object_from_image(
    image_bytes: bytes,
    mime_type: str,
    reference_description: str = None,
    reference_dimension_mm: float = None,
) -> str:
    """
    Manda la foto a Gemini in modalità visione e ritorna una descrizione
    testuale pronta per essere usata come prompt di generazione CAD.

    reference_description / reference_dimension_mm: se l'utente indica un
    oggetto di dimensione nota visibile nella foto (es. "diametro della
    moneta da 1 euro", 23.25), viene usato per calibrare la stima. Se
    omessi, la descrizione risultante segnala esplicitamente l'incertezza
    di scala (vedi regola 3 del system prompt).
    """
    image_b64 = base64.b64encode(image_bytes).decode("utf-8")

    instruction_parts = [
        {"text": "Analizza questa fotografia e descrivi l'oggetto per la ricostruzione CAD, seguendo le regole date."}
    ]

    if reference_description and reference_dimension_mm:
        instruction_parts.append({
            "text": (
                f"Riferimento di scala presente nella foto: {reference_description}, "
                f"dimensione nota = {reference_dimension_mm}mm. Usalo per calibrare "
                "tutte le altre misure per proporzione rispetto a questo riferimento."
            )
        })

    contents = [{
        "role": "user",
        "parts": instruction_parts + [
            {"inline_data": {"mime_type": mime_type, "data": image_b64}}
        ],
    }]

    return _call_gemini(contents, system_instruction=VISION_SYSTEM_PROMPT).strip()
