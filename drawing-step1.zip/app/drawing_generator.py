"""
Generatore di disegni tecnici 2D a partire da un solido CadQuery.

Approccio incrementale deliberato: dopo la sessione di debug sui poliedri
(4 tentativi falliti su API OCCT non verificabili prima di cambiare
strategia), questo modulo si costruisce un pezzo alla volta, verificando
ogni pezzo in isolamento PRIMA di costruirci sopra il successivo -- invece
di scrivere l'intera pipeline multi-vista in un colpo solo basandosi su
parametri che non posso testare da qui.

STATO ATTUALE: Passo 1 -- singolo export SVG con le impostazioni di
default di CadQuery (nessuna opzione custom, per minimizzare il rischio
di API sbagliate). Da verificare prima di aggiungere viste multiple,
quote, e composizione in un foglio disegno.

Si applica SOLO ai risultati CadQuery normali (Workplane/Assembly, quelli
con export STEP) -- non ai solidi platonici mesh-only (build_platonic_solid),
per cui servirebbe una logica di proiezione diversa basata sulla mesh
triangolare invece che sul BREP.
"""

import cadquery as cq


def export_single_view_svg(result, svg_path: str) -> dict:
    """
    Esporta una singola vista SVG di 'result' con le impostazioni di
    default dell'exporter CadQuery -- nessuna opzione custom (projectionDir,
    dimensioni, margini) per ridurre al minimo il rischio di parametri
    sbagliati che non posso verificare in questo ambiente.

    Ritorna {"success": bool, "error": str o None}.
    """
    try:
        cq.exporters.export(result, svg_path, exportType=cq.exporters.ExportTypes.SVG)
        return {"success": True, "error": None}
    except Exception as e:
        return {"success": False, "error": str(e)}
