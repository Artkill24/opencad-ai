"""
Foto -> descrizione geometrica PROPORZIONALE (non foto -> misure assolute).

Perché niente numeri assoluti in questo step: una singola fotografia non
contiene l'informazione di scala necessaria per misure affidabili -- anche
chiedendo di confrontare pixel con un oggetto di riferimento nell'inquadratura,
la stima resta fragile (dipende da prospettiva, angolo di ripresa, distanza).
Il modo affidabile di ottenere una misura reale è che l'utente stesso la prenda
con un calibro/righello sull'oggetto fisico -- non che l'AI la indovini da una
foto.

Quindi questo modulo fa una cosa sola, e la fa bene: guarda la foto e descrive
la FORMA in termini proporzionali (rapporti, multipli) rispetto a UNA
dimensione caratteristica che sceglie e nomina esplicitamente (es. "il
diametro esterno"). L'utente fornisce poi il valore reale in mm di quella
singola dimensione, misurata sull'oggetto vero -- e quel valore, combinato
con le proporzioni descritte, permette al passo successivo (generazione CAD,
già esistente) di calcolare tutte le quote in millimetri.
"""

import base64

from llm_pipeline import _call_gemini

VISION_SYSTEM_PROMPT = """
Sei un ingegnere meccanico che osserva la fotografia di un oggetto fisico e
ne descrive la FORMA -- non le dimensioni assolute -- per la ricostruzione CAD.

Il tuo compito NON è generare codice, e NON è stimare misure in millimetri:
una singola fotografia non contiene l'informazione di scala necessaria per
misure affidabili, quindi qualunque numero assoluto che daresti sarebbe
inventato. Descrivi invece la geometria in termini PROPORZIONALI, tutti
relativi a UNA sola dimensione caratteristica dell'oggetto che tu stesso
scegli e nomini chiaramente (es. "il diametro esterno del cilindro",
"la lunghezza della base", "l'altezza totale").

REGOLE RIGIDE:
1. La primissima riga della risposta deve essere ESATTAMENTE in questo
   formato, senza altro testo prima:
   DIMENSIONE_RIFERIMENTO: <nome breve e chiaro della dimensione scelta>
   Esempio: DIMENSIONE_RIFERIMENTO: diametro esterno del cilindro
2. Dopo quella riga, descrivi la forma come combinazione di primitive
   geometriche semplici (cilindri, blocchi, coni, fori, smussi, pattern
   circolari), esprimendo OGNI altra misura come frazione o multiplo della
   dimensione di riferimento -- es. "l'altezza è circa 1.5 volte la
   dimensione di riferimento", "il foro centrale ha diametro pari a un
   terzo della dimensione di riferimento", "sono presenti 4 fori aggiuntivi
   disposti su una circonferenza pari a due terzi della dimensione di
   riferimento".
3. NON usare MAI numeri assoluti in millimetri, centimetri o pollici in
   questa fase -- solo rapporti, frazioni, multipli della dimensione di
   riferimento.
4. Evita forme organiche, curve libere o dettagli che non si possono
   ridurre a primitive geometriche semplici; se necessario, semplifica e
   dillo esplicitamente nella descrizione.
5. Non descrivere colori, materiali, texture, riflessi o dettagli estetici
   -- SOLO geometria: forma, proporzioni, fori, simmetrie, spessori relativi.
6. Rispondi ESCLUSIVAMENTE con la riga DIMENSIONE_RIFERIMENTO seguita dalla
   descrizione proporzionale. Nessuna premessa, nessuna spiegazione del tuo
   ragionamento, nessun markdown.
"""


def describe_shape_from_image(image_bytes: bytes, mime_type: str) -> dict:
    """
    Manda la foto a Gemini in modalità visione e ritorna la forma come
    descrizione proporzionale, insieme al nome della dimensione di
    riferimento scelta dal modello -- che il chiamante userà per etichettare
    il campo dove l'utente inserirà la misura reale in mm.

    Ritorna: {"reference_dimension_name": str, "proportional_description": str}
    """
    image_b64 = base64.b64encode(image_bytes).decode("utf-8")

    contents = [{
        "role": "user",
        "parts": [
            {"text": "Analizza questa fotografia e descrivi la FORMA dell'oggetto in termini proporzionali, seguendo le regole date."},
            {"inline_data": {"mime_type": mime_type, "data": image_b64}},
        ],
    }]

    raw = _call_gemini(contents, system_instruction=VISION_SYSTEM_PROMPT).strip()

    first_line, _, rest = raw.partition("\n")
    prefix = "DIMENSIONE_RIFERIMENTO:"
    if first_line.strip().upper().startswith(prefix):
        reference_name = first_line.split(":", 1)[1].strip()
        description = rest.strip()
    else:
        reference_name = "dimensione principale"
        description = raw

    return {
        "reference_dimension_name": reference_name,
        "proportional_description": description,
    }
