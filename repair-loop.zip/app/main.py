from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import os
from llm_pipeline import generate_cad_code_with_repair
from cad_engine import execute_and_export
from geometry_checks import detect_static_warnings

app = FastAPI(title="OpenCAD-AI Core Backend", version="0.1.0")

os.makedirs("outputs", exist_ok=True)
app.mount("/outputs", StaticFiles(directory="outputs"), name="outputs")
app.mount("/static", StaticFiles(directory="static"), name="static")


class CADRequest(BaseModel):
    prompt: str
    output_name: str = "generated_model"
    timeout: int = 15
    max_attempts: int = 3


@app.get("/")
async def serve_frontend():
    return FileResponse("static/index.html")


@app.post("/api/v1/generate")
async def generate_cad(request: CADRequest):
    output_dir = "outputs"
    os.makedirs(output_dir, exist_ok=True)
    file_prefix = os.path.join(output_dir, request.output_name)

    def execute_fn(code: str) -> dict:
        return execute_and_export(code, base_filename=file_prefix, timeout=request.timeout)

    repair_result = generate_cad_code_with_repair(
        request.prompt, execute_fn, max_attempts=request.max_attempts
    )

    python_code = repair_result["code"]
    exec_result = repair_result["exec_result"]

    if not exec_result["success"]:
        raise HTTPException(
            status_code=422,
            detail={
                "status": "compilation_error",
                "message": exec_result["error"],
                "generated_code": python_code,
                "attempts": repair_result["attempts"],
            }
        )

    warnings = detect_static_warnings(python_code)
    status = "geometria_sospetta" if warnings else "success"

    return {
        "status": status,
        "warnings": warnings,
        "generated_code": python_code,
        "volume_mm3": exec_result.get("volume_mm3"),
        "bbox_mm": exec_result.get("bbox_mm"),
        "files": exec_result["files"],
        "attempts": repair_result["attempts"],
        "repaired": repair_result["repaired"],
    }


@app.get("/health")
def health_check():
    return {"status": "ok"}
