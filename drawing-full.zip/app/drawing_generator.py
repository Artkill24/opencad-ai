"""
Generatore di disegni tecnici 2D a partire da un solido CadQuery.

Le tre direzioni di proiezione usate qui NON sono gli assi puri (1,0,0)
ecc: verificato empiricamente che gli assi puri causano un caso degenere
nella costruzione del sistema di coordinate OCCT sottostante (gp_Ax2),
producendo viste sbagliate senza sollevare errori. Una piccola perturbazione
(1e-3) evita il caso degenere restando praticamente ortogonale.

Mappatura vista -> assi visibili, verificata numericamente su un blocco
di prova 80x40x20mm (non assunta dalla documentazione, misurata):
  - "top"   (lungo Z): mostra X in orizzontale, Y in verticale (pianta)
  - "front" (lungo Y): mostra Z in orizzontale, X in verticale (fronte)
  - "side"  (lungo X): mostra Z in orizzontale, Y in verticale (laterale)

LIMITI ONESTI (v1):
- Solo le quote d'ingombro complessive (bounding box) sono mostrate nel
  cartiglio, non le quote di ogni feature interna (fori, raggi, smussi) --
  un vero disegno GD&T completo è un lavoro sostanzialmente più grande.
- Le linee nascoste sono mostrate tratteggiate (comportamento di default
  dell'exporter CadQuery), non disattivabili in questa v1.
- Non applicabile ai solidi platonici mesh-only (build_platonic_solid) --
  quelli non hanno un BREP da cui l'exporter SVG possa generare proiezioni;
  servirebbe una logica di proiezione basata sulla mesh triangolare.
- La composizione del foglio (posizione delle 3 viste, dimensioni) è
  verificata solo strutturalmente (XML valido, viste presenti) -- non ho
  potuto verificare visivamente che il risultato sia leggibile/ben
  impaginato, perché non ho un modo di vedere il rendering da qui.
"""

import os
import tempfile
import xml.etree.ElementTree as ET

import cadquery as cq

SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)  # evita il prefisso ns0: nell'output serializzato

_EPS = 0.001
VIEW_DIRECTIONS = {
    "top":   (_EPS, _EPS, 1.0),
    "front": (_EPS, 1.0, _EPS),
    "side":  (1.0, _EPS, _EPS),
}
VIEW_LABELS = {"top": "PIANTA", "front": "FRONTE", "side": "LATERALE"}


def _export_view_fragment(result, direction, width: int, height: int) -> str:
    """
    Esporta una singola vista e ne estrae il gruppo <g> principale (il
    disegno vero e proprio) come stringa XML valida, pronta per essere
    incorporata in un foglio con più viste. Usa xml.etree invece di regex
    sul testo grezzo -- più robusto per estrarre un tag annidato senza
    rischiare di tagliare a metà per un match greedy sbagliato.
    """
    with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        cq.exporters.export(
            result, tmp_path, exportType=cq.exporters.ExportTypes.SVG,
            opt={
                "projectionDir": direction,
                "showAxes": False,
                "width": width,
                "height": height,
                "showHidden": True,
            },
        )
        tree = ET.parse(tmp_path)
        root = tree.getroot()
        main_group = root.find(f"{{{SVG_NS}}}g")
        if main_group is None:
            raise RuntimeError("Nessun gruppo <g> trovato nell'SVG esportato -- formato inatteso.")
        return ET.tostring(main_group, encoding="unicode")
    finally:
        os.unlink(tmp_path)


def generate_technical_drawing(result, svg_path: str, bbox_mm: dict = None) -> dict:
    """
    Genera un foglio disegno con 3 viste ortogonali (pianta, fronte,
    laterale) più le quote d'ingombro complessive, a partire da un solido
    CadQuery (Workplane/Assembly -- non applicabile a mesh trimesh).

    Ritorna {"success": bool, "error": str o None}. Non solleva eccezioni
    verso il chiamante -- un fallimento qui è un'informazione in meno, non
    un motivo per considerare fallita l'intera generazione del pezzo.
    """
    try:
        view_w, view_h = 260, 220
        margin = 30

        fragments = {
            nome: _export_view_fragment(result, direzione, view_w, view_h)
            for nome, direzione in VIEW_DIRECTIONS.items()
        }

        sheet_w = 2 * view_w + 3 * margin
        sheet_h = 2 * view_h + 3 * margin + 60  # spazio extra per il cartiglio

        # Disposizione: pianta in alto a sinistra, fronte in basso a
        # sinistra, laterale in basso a destra -- layout comune nel
        # disegno tecnico multi-vista.
        positions = {
            "top":   (margin, margin),
            "front": (margin, margin * 2 + view_h),
            "side":  (margin * 2 + view_w, margin * 2 + view_h),
        }

        svg_parts = [
            f'<svg xmlns="{SVG_NS}" width="{sheet_w}" height="{sheet_h}">',
            f'<rect x="0" y="0" width="{sheet_w}" height="{sheet_h}" fill="white" stroke="black" stroke-width="1"/>',
        ]

        for nome, (x, y) in positions.items():
            svg_parts.append(f'<g transform="translate({x},{y})">')
            svg_parts.append(
                f'<rect x="0" y="0" width="{view_w}" height="{view_h}" '
                'fill="none" stroke="#cccccc" stroke-width="0.5"/>'
            )
            svg_parts.append(fragments[nome])
            svg_parts.append(
                f'<text x="5" y="{view_h - 5}" font-size="10" font-family="monospace">'
                f'{VIEW_LABELS[nome]}</text>'
            )
            svg_parts.append("</g>")

        if bbox_mm:
            quote_text = (
                f"Ingombro: {bbox_mm.get('x', '?')} x {bbox_mm.get('y', '?')} x "
                f"{bbox_mm.get('z', '?')} mm"
            )
            svg_parts.append(
                f'<text x="{margin}" y="{sheet_h - 20}" font-size="12" '
                f'font-family="monospace">{quote_text}</text>'
            )
            svg_parts.append(
                f'<text x="{margin}" y="{sheet_h - 5}" font-size="9" '
                'font-family="monospace" fill="#666666">'
                "Solo quote d'ingombro complessive -- non un disegno GD&amp;T completo.</text>"
            )

        svg_parts.append("</svg>")
        full_svg = "\n".join(svg_parts)

        # Verifica strutturale prima di scrivere: l'XML composto deve
        # essere valido (non solo "sembrare" corretto per concatenazione
        # di stringhe) -- se ET.fromstring fallisce, meglio scoprirlo qui
        # con un errore chiaro che spedire un file rotto.
        ET.fromstring(full_svg)

        with open(svg_path, "w") as f:
            f.write(full_svg)

        return {"success": True, "error": None}

    except Exception as e:
        return {"success": False, "error": str(e)}
