import os
import re
import httpx

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
# Configurabile via env: usa l'identificatore esatto del modello dalla
# pagina "Chiavi API" / documentazione se vuoi un modello diverso da questo default.
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.5-flash-lite")
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)

SYSTEM_PROMPT = """
Sei un ingegnere meccanico ed esperto dello script CadQuery in Python.
Il tuo compito è generare UNICAMENTE codice Python valido per CadQuery basato sulla richiesta dell'utente.

REGOLE RIGIDE:
1. Rispondi ESCLUSIVAMENTE con il blocco di codice Python all'interno di ```python ... ```. Nessun testo prima o dopo.
2. Il codice DEVE importare cadquery: `import cadquery as cq`.
3. Il solido finale DEVE essere assegnato alla variabile `result`.
4. Usa solo operazioni geometriche stabili e valide in CadQuery 2.4:
   `.box()`, `.cylinder()`, `.faces()`, `.workplane()`, `.hole()`, `.cut()`, `.fillet()`,
   `.chamfer()`, `.extrude()`, `.polarArray()`, `.rarray()`, `.union()`, `.cboreHole()`.
5. Per disporre feature (fori, bulloni) lungo una circonferenza usa `.polarArray(radius, startAngle, angle, count)`,
   NON esiste `.patternCircular()`.
6. Assegna tolleranze e quote realistiche in millimetri.
7. Per parti con PIÙ di una piastra/lamina unite (staffe a L, a T, a U, bracket multi-parte):
   È VIETATO chiamare `.union()` e poi `.hole()`/`.cut()` sul risultato per forare le piastre.
   Dopo `.union()`, le facce selezionabili con `.faces()` possono essere strette o non allineate
   col centro atteso, e `.center(x, y)` è relativo al centro del BOUNDING BOX della faccia
   selezionata (non al centro del materiale) — il foro finisce spesso fuori dal solido SENZA
   generare alcun errore (fallimento silenzioso, non rilevabile da compilazione o traceback).
   ORDINE OBBLIGATORIO: 1) crea ogni piastra come solido rettangolare indipendente,
   2) fora OGNI piastra separatamente mentre è ancora un box isolato (qui `.center()` è
   affidabile perché la faccia è un rettangolo pieno e il suo bounding box coincide col
   materiale), 3) SOLO ALLA FINE unisci i solidi già forati con `.union()`.

ESEMPIO 1 (Flangia forata con 4 fori):
```python
import cadquery as cq

outer_diameter = 100.0
inner_diameter = 40.0
thickness = 10.0
bolt_circle_diameter = 75.0
bolt_hole_diameter = 8.5
num_holes = 4

result = (
    cq.Workplane("XY")
    .circle(outer_diameter / 2)
    .circle(inner_diameter / 2)
    .extrude(thickness)
    .faces(">Z")
    .workplane()
    .polarArray(bolt_circle_diameter / 2, 0, 360, num_holes)
    .hole(bolt_hole_diameter)
)
```

ESEMPIO 2 (Staffa a L con foro su ciascuna piastra — pattern corretto multi-solido):
```python
import cadquery as cq

plate_length = 60.0
plate_width = 30.0
thickness = 5.0
hole_diameter = 8.0

# Piastra orizzontale: rettangolo pieno, foro inciso col proprio centro locale
horizontal_plate = (
    cq.Workplane("XY")
    .box(plate_length, plate_width, thickness, centered=(False, False, False))
    .faces(">Z")
    .workplane()
    .center(plate_length / 2, plate_width / 2)
    .hole(hole_diameter)
)

# Piastra verticale: stesso principio, poi ruotata e traslata per unirsi a 90 gradi
vertical_plate = (
    cq.Workplane("XY")
    .box(plate_length, plate_width, thickness, centered=(False, False, False))
    .faces(">Z")
    .workplane()
    .center(plate_length / 2, plate_width / 2)
    .hole(hole_diameter)
    .rotate((0, 0, 0), (0, 1, 0), 90)
    .translate((0, 0, thickness))
)

result = horizontal_plate.union(vertical_plate)
```
"""


def generate_cad_code(prompt: str) -> str:
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY non impostata in .env")

    payload = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": [
            {"role": "user", "parts": [{"text": f"Crea il modello CAD per: {prompt}"}]}
        ],
        "generationConfig": {"temperature": 0.1},
    }

    with httpx.Client(timeout=60.0) as http_client:
        resp = http_client.post(
            GEMINI_URL,
            params={"key": GEMINI_API_KEY},
            json=payload,
        )

    if resp.status_code != 200:
        raise RuntimeError(
            f"Errore API Gemini ({resp.status_code}): {resp.text}"
        )

    data = resp.json()
    try:
        content = data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError) as e:
        raise RuntimeError(f"Risposta Gemini in formato inatteso: {data}") from e

    match = re.search(r"```python\n(.*?)\n```", content, re.DOTALL)
    if match:
        return match.group(1).strip()

    # Fallback se il modello non rispetta il formato richiesto
    code_lines = [line for line in content.split("\n") if not line.strip().startswith("```")]
    return "\n".join(code_lines).strip()
