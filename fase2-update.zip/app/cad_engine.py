import sys
import io
import re
import traceback
import multiprocessing
import cadquery as cq


def detect_static_warnings(code_str: str) -> list:
    """
    Controlli statici (analisi testuale, nessuna esecuzione) su pattern noti
    per produrre fallimenti geometrici silenziosi -- non bloccano l'export,
    ma segnalano al chiamante che il risultato va verificato con più attenzione.
    """
    warnings = []

    union_matches = list(re.finditer(r"\.union\s*\(", code_str))
    cut_hole_matches = list(re.finditer(r"\.(hole|cut)\s*\(", code_str))

    if union_matches and cut_hole_matches:
        first_union_pos = union_matches[0].start()
        last_cut_hole_pos = cut_hole_matches[-1].start()
        if last_cut_hole_pos > first_union_pos:
            warnings.append(
                "Rilevata chiamata a .hole()/.cut() dopo .union(): pattern noto per "
                "produrre fori fuori dal materiale su parti multi-solido senza generare "
                "errori. Verifica il volume/bounding box del risultato."
            )

    return warnings


def _run_in_subprocess(code_str: str, step_path: str, stl_path: str, queue: multiprocessing.Queue):
    """
    Gira in un processo separato: exec dello script, validazione result,
    export STEP/STL, calcolo volume/bounding box per verifica geometrica.
    Comunica solo dati picklabili (dict) al processo padre.
    """
    local_scope = {}
    global_scope = {"cq": cq}

    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    try:
        exec(code_str, global_scope, local_scope)
        result = local_scope.get("result")

        if result is None:
            queue.put({"success": False, "error": "Lo script non ha definito la variabile 'result'."})
            return

        if not isinstance(result, (cq.Workplane, cq.Assembly)):
            queue.put({
                "success": False,
                "error": f"'result' deve essere cq.Workplane o cq.Assembly, ottenuto {type(result)}."
            })
            return

        cq.exporters.export(result, step_path, exportType=cq.exporters.ExportTypes.STEP)
        cq.exporters.export(
            result, stl_path,
            exportType=cq.exporters.ExportTypes.STL,
            tolerance=0.01, angularTolerance=0.1
        )

        # Metriche geometriche per verifica post-hoc (solo per Workplane con un solido;
        # per geometrie composite/Assembly il calcolo è meno affidabile, lo saltiamo).
        volume_mm3 = None
        bbox_mm = None
        try:
            solid = result.val()
            if hasattr(solid, "Volume") and hasattr(solid, "BoundingBox"):
                volume_mm3 = round(solid.Volume(), 1)
                bbox = solid.BoundingBox()
                bbox_mm = {
                    "x": round(bbox.xlen, 2),
                    "y": round(bbox.ylen, 2),
                    "z": round(bbox.zlen, 2),
                }
        except Exception:
            pass  # metriche opzionali: se falliscono non blocchiamo l'export già riuscito

        queue.put({
            "success": True,
            "error": None,
            "volume_mm3": volume_mm3,
            "bbox_mm": bbox_mm,
        })

    except Exception as e:
        queue.put({"success": False, "error": f"{str(e)}\n{traceback.format_exc()}"})
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr


def execute_and_export(code_str: str, base_filename: str = "output", timeout: int = 15) -> dict:
    """
    Esegue lo script CadQuery in un processo isolato con timeout hard.
    Ritorna dict con success, error, volume/bbox (se disponibili), e (se ok) files.
    """
    step_path = f"{base_filename}.step"
    stl_path = f"{base_filename}.stl"

    queue = multiprocessing.Queue()
    proc = multiprocessing.Process(
        target=_run_in_subprocess,
        args=(code_str, step_path, stl_path, queue)
    )
    proc.start()
    proc.join(timeout)

    if proc.is_alive():
        proc.terminate()
        proc.join()
        return {
            "success": False,
            "error": f"Timeout: esecuzione oltre {timeout}s (probabile loop infinito o geometria troppo complessa)."
        }

    if queue.empty():
        return {
            "success": False,
            "error": f"Processo terminato senza risultato (crash, exit code {proc.exitcode})."
        }

    result = queue.get()
    if result["success"]:
        result["files"] = {"step_path": step_path, "stl_path": stl_path}
    return result
