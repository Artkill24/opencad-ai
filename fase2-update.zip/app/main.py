from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import os
from llm_pipeline import generate_cad_code
from cad_engine import execute_and_export, detect_static_warnings

app = FastAPI(title="OpenCAD-AI Core Backend", version="0.1.0")

os.makedirs("outputs", exist_ok=True)
app.mount("/outputs", StaticFiles(directory="outputs"), name="outputs")
app.mount("/static", StaticFiles(directory="static"), name="static")


class CADRequest(BaseModel):
    prompt: str
    output_name: str = "generated_model"
    timeout: int = 15


@app.get("/")
async def serve_frontend():
    return FileResponse("static/index.html")


@app.post("/api/v1/generate")
async def generate_cad(request: CADRequest):
    python_code = generate_cad_code(request.prompt)

    output_dir = "outputs"
    os.makedirs(output_dir, exist_ok=True)
    file_prefix = os.path.join(output_dir, request.output_name)

    result = execute_and_export(python_code, base_filename=file_prefix, timeout=request.timeout)

    if not result["success"]:
        raise HTTPException(
            status_code=422,
            detail={
                "status": "compilation_error",
                "message": result["error"],
                "generated_code": python_code
            }
        )

    warnings = detect_static_warnings(python_code)
    status = "geometria_sospetta" if warnings else "success"

    return {
        "status": status,
        "warnings": warnings,
        "generated_code": python_code,
        "volume_mm3": result.get("volume_mm3"),
        "bbox_mm": result.get("bbox_mm"),
        "files": result["files"]
    }


@app.get("/health")
def health_check():
    return {"status": "ok"}
